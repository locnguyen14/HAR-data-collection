'''
Network support
===============

Kivy currently supports basic, asynchronous network requests.
Please refer to :class:`kivy.network.urlrequest.UrlRequest`.
'''
