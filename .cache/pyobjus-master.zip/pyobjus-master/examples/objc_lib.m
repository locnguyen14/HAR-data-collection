//
//  main.m
//  pyobjus_test
//
//  Created by Ivan on 8/3/13.
//  Copyright (c) 2013 Ivan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjcClass : NSObject {
}
@end

@implementation ObjcClass

- (void) printFromObjectiveC {
    printf("Hello from Objective C\n");
}

@end